
<?php

include 'index.php';  /*navigations*/	


include 'dbconnect.php';  /*Connecting to MySQL*/

$result = mysql_query("select * from movies")
  or die("Could not issue MySQL query");     


if (mysql_num_rows ($result) == 0) {
	print("No results matching your query <br>\n");
} 
else 
{
	echo "<table border='1'>";
	echo "<tr><th>Movie</th><th>publish year</th><th>Genre</th><th>Rating</th></tr>";
	while($row = mysql_fetch_row($result))
	{
		echo "<tr><td>";
		echo $row[1];
		echo "</td><td>";
		echo $row[2];
		echo "</td><td>";
		$getGenre = mysql_query("select id, name from genre"); 
		while($genreRow = mysql_fetch_assoc($getGenre)) { 
	   	if ($row[3] == $genreRow["id"])
		{echo $genreRow["name"];}  
		}
		echo "</td><td>";
		echo $row[4];
		echo "</td></tr>";
	}
echo "</table>";
}

include 'dbclose.php';  /*Disconnecting to MySQL*/
?>

