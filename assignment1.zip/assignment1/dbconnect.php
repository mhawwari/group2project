<?php



/*Connecting to MySQL*/
$hostname = "localhost";
$username = "root";
$password = "";
$connection = mysql_connect($hostname, $username, $password)
     or die("Could not open connection to database");


/*Select a database*/
mysql_select_db("moviesDB", $connection)
  or die("Could not select database");

?>

