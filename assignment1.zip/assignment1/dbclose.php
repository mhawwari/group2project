<?php
mysql_close($connection)
or die("Could not close connection to database");
?>