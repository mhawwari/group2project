<?php echo "<link href='stylesheet.css' rel='stylesheet' type='text/css'>"; ?>
<div id="header" class="text">
<a href="viewMovie.php">View Movies</a> 
<a href="addMovie.php">Add Movie</a></div> 
<br><br>
