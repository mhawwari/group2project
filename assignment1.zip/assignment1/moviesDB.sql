DROP DATABASE if exists moviesDB;
CREATE DATABASE moviesDB;
USE moviesDB;

CREATE TABLE movies
(
  id INT PRIMARY KEY AUTO_INCREMENT,
  name varchar(100) NOT NULL,
  year varchar(4) NOT NULL,
  genre INT NOT NULL,
  rating INT NOT NULL
);


CREATE TABLE genre
(
	id INTEGER PRIMARY KEY AUTO_INCREMENT,
	name varchar(100) 
);

INSERT INTO genre(name) VALUES('Action/Adventure'),('Comedy'),('Drama'),('Fantasy/Sci-Fi');


SELECT * FROM movies;
SELECT * FROM genre;
