<?php
include 'index.php';  /*navigations*/	

include 'dbconnect.php';

$movie_name = $_POST["movie_name"];
$movie_year = $_POST["movie_year"];
$genre = $_POST["genre"];
$rating = $_POST["rating"];

$result = mysql_query("insert into movies(name, year, genre, rating) values('".$movie_name."','".$movie_year."',".$genre.",".$rating.")")
or die("Adding failed");

  	print("The movie $movie_name was added successfully!");

  include 'dbclose.php';
?>