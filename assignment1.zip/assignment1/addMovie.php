	<?php include 'index.php';  /*navigations*/	?>

<div id="form">
<form action="post_movie.php" method="POST">
	

	
	<div><span>Name:</span><input id="box" type="text" name="movie_name"></div>
	<div><span>Year:</span><select id="box" name = "movie_year">
	<?php 
	$year = 1900;
	while($year != date('Y')+1)
	{
    echo '<option id='.$year.'>'.$year.'</option>';
    $year++;
	}  ?>
	</select></div>
	<!-- <div>Year:<input type="text" name="movie_year"></div> -->
	<div><span>Genre:</span><?php include 'genres.php'; ?></div>
	<div><span>Rating:</span><select id="box" name = "rating">
				<option id='1'>1</option>
				<option id='2'>2</option>
				<option id='3'>3</option>
				<option id='4'>4</option>
				<option id='5'>5</option>
				</select></div>
	<input id="add" type="submit" value="Add Movie">
</form>
</div>