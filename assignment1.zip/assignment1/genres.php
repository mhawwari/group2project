<select id="box" name="genre"> 
	<?php 
	include 'dbconnect.php'; //establish database connection script
	$result = mysql_query("select id, name from genre"); 
	while($row = mysql_fetch_assoc($result)) { 
	   	$id = $row["id"];
		$name = $row["name"]; 
		print "<option value='$id'>$name</option>"; 
	} 
	include 'dbclose.php';  //close database connection script	 	
	?> 
</select>
